Mewjector v2.0
==============

A DLL mod loader for Mewgenics.
Works with Mewtator (https://www.nexusmods.com/mewgenics/mods/1),
the Mewgenics mod manager.

If you also have Mewtator installed, they handshake automatically
through chainloader.ini.

INSTALLATION
------------
1. Copy version.dll and chainloader.ini into your Mewgenics
   directory (the folder containing the game's .exe file).

USING MEWTATOR? You're done! Just enable DLL mods in Mewtator's
settings and it handles the rest.

MANUAL SETUP (without Mewtator):

2. Create a "mods" folder in the same directory.

3. Drop your mod .dll files into the mods/ folder.

4. Launch the game normally.

5. Check mod_logs/chainloader.log to verify mods loaded correctly.


CONFIGURATION
-------------
Edit chainloader.ini to change settings. See comments in the file
for details on each option.


LOAD ORDER
----------
Loose DLLs in your mods/ folder load in alphabetical order by
default. If you need a specific DLL to load first (e.g. a hook
library that other mods depend on), add a [LoadOrder] section to
chainloader.ini:

  [LoadOrder]
  1=core_hooks.dll
  2=my_framework.dll

Priority DLLs load first in the listed order, then everything
else loads alphabetically. For full load order management with
a GUI, use Mewtator instead.


TROUBLESHOOTING
---------------
- Check mod_logs/chainloader.log for error messages
- Set Logging=1 in chainloader.ini if logging is off
- Set Enabled=0 to disable mod loading without removing files


SOURCE CODE
-----------
https://github.com/githubuser508/mewjector

Licensed under the MIT License.
