#include "ffi/cat_factory.hpp"
#include "amoeba.hpp"
#include "utilities/debug_console.hpp"
#include "utilities/function_hook.hpp"
#include "utilities/sqlite3_conn_wrapper.hpp"
#include "utilities/portal.hpp"

#include <cstring>
#include <stack>

#include "lz4.h"

// Utilities for producing CatData objects.
//
// polymeric 2026

MAKE_SDPORTAL(DATAOFF_glaiel__MewDirector__p_singleton,
    MewDirector *, get_p_mewdirector_singleton
)

MAKE_STPORTAL(0, TLS0OFF_xoshiro256p_rng_context,
    Xoshiro256pContext, get_xoshiro256p_rng_context
)

MAKE_SFPORTAL(ADDRESS_glaiel__CatData_ctor,
    CatData *, __cdecl, glaiel__CatData_ctor,
    (CatData *thiss),
    (thiss)
)

MAKE_SFPORTAL(ADDRESS_glaiel__CatData_dtor,
    void, __cdecl, glaiel__CatData_dtor,
    (CatData *thiss),
    (thiss)
)

void CatDataDeleter::operator()(CatData *p_cat) const {
    glaiel__CatData_dtor(p_cat);
    operator delete(p_cat);
}

ManagedCatData new_default_cat() {
    CatData *p_new_cat = reinterpret_cast<CatData *>(operator new(sizeof(CatData)));
    std::memset(reinterpret_cast<void *>(p_new_cat), 0, sizeof(CatData));
    glaiel__CatData_ctor(p_new_cat);

    return ManagedCatData(p_new_cat);
}

MAKE_SFPORTAL(ADDRESS_glaiel__SerializeCatData,
    void, __cdecl, glaiel__SerializeCatData,
    (struct CatData* cat, struct ByteStream *byte_stream, bool assert_version_cutoff_on_load),
    (cat, byte_stream, assert_version_cutoff_on_load)
)

ManagedCatData load_cat(int64_t sql_id) {
    // TITLE: Dr. Beanies' guide to (safe?) cat resurrection
    // LECTURER: Beanies, Thomas A., Dr.
    // RIGHTSHOLDER: Beanies Teaching Films, Ltd.
    // YEAR OF PRODUCTION: 1958 (MCMLVIII)

    MewDirector *p_md = get_p_mewdirector_singleton();

    if(p_md == nullptr) {
        return nullptr;
    }

    std::vector<char> decompressed_cat;
    // Here's an important tip for successful cat resurrection!
    // Remember to obtain a cryopreserved cat in the first place!
    // You may often find prepared specimen at your local morgue, or the cats table of your save file!
    G.sqlite3.exec_path(
        std::filesystem::path(p_md->sqlsavefile.file_path.as_native_string_view()),
        "SELECT data from cats WHERE key = :key;",
        {std::make_pair(":key", sql_id)},
        [&decompressed_cat](sqlite3_stmt * stmt) -> bool {
            // This corpse may currently look like a nondescript blob, but rest assured,
            // it shall be alive and kicking again in no time!
            const char *blob = reinterpret_cast<const char *>(sqlite3_column_blob(stmt, 0));
            int size = sqlite3_column_bytes(stmt, 0);

            // Sometimes the morgue may not have cats available, or you selected the wrong compartment numbers in your search!
            // Always have an escape plan for when you hear the mortician coming!
            if(size == 0) {
                D::warn("A cat blob in the cats table has 0 size!");
                return false;
            }

            // Cryopreserved cats are often embalmed with an agent known as "LZ4", invented by the world-renowned Mr. Collet!
            // While effective at preserving the dead, it is decidely not for the living!
            // Fortunately, "LZ4" can be removed with these simple steps, known as the "LZ4 decompression process"!
            int decompressed_size = reinterpret_cast<const int *>(blob)[0];
            decompressed_cat.resize(decompressed_size);
            if(LZ4_decompress_safe(blob + 4, decompressed_cat.data(), size - 4, decompressed_size) != decompressed_size) {
                D::error("An LZ4-compressed cat failed to decompress!");
                // Gentle reminder! It's a good habit to clean your equipment!
                // Helps to alleviate those messy cases!
                std::vector<char>().swap(decompressed_cat);
                return false;
            }

            return false;
        }
    );

    // As I mentioned earlier, be ready to bail at any time!
    // $1,000 and a change of clothes in a trusted confidant's home provides sufficient insurance, from my experience!
    if(decompressed_cat.size() == 0) {
        return nullptr;
    }

    // Now we need to prepare a glaiel::ByteStream!
    // The namesake of this apparatus comes from the venerated Professor Glaiel, an unparalleled genius of his era!
    // Even I, Thomas A. Beanies, with my 2 PhDs, barely understand enough to use a fraction of its full potential!
    ByteStream byte_stream = {};
    byte_stream.direction_0_des_buffer_1_ser_buffer_2_ser_ostream = 0;
    byte_stream.either_platform_or_stream_endianness = 0;
    byte_stream.either_stream_or_platform_endianness = 0;
    byte_stream.maximum_auto_endian_swap_size = 8;
    byte_stream.string_intern_table = nullptr;
    byte_stream.des_buffer = decompressed_cat.data();
    byte_stream.des_buffer_size = static_cast<int>(decompressed_cat.size());
    byte_stream.des_buffer_needs_free = false;
    byte_stream.des_buffer_read_cursor = 0;

    // (Notably, the glaiel::ByteStream can handle "LZ4 decompression" itself, but allowing it to do so
    // creates internal allocations, which are best avoided when we cannot easily see how it works!)

    // I've nearly forgotten to mention! You need a donor cat to complete the operation!
    // *I* need a donor cat to complete this demonstration!
    // ... What to do? ...
    // We'll synthesize one from scratch!
    ManagedCatData new_cat = new_default_cat(); // And while we're at it, don't forget to implant a remote detonator!

    // (The astute among you will note that proper cat synthesis requires several more procedures,
    // some of which involve defying the very designs of God [1]!
    // We omit them here, as this shall be a mere laboratory cat, not destined for the great outdoors!)
    // ---
    // [1]: It is scarce worth noting that the doctor is speaking of the process of genetic recombination
    //      in an allegorical sense, and is not offering theological or scientific advice.

    // (Question from the audience?
    // [...]
    // Well well well, somebody clearly slept through their Catology 101 lectures!
    // Recall the conventional synthesis process:
    //     1) capture the state of the universe,
    //     2) allow Mother Nature to do her delicate work on the cat's genes,
    //     3) reshape the genes with the ingenuity of Man,
    //     4) wind the universe back to the previously captured state.
    // [...]
    // Yes, omitting steps 1 and 4 is a sure cause for timeline fragmentation!
    // [...]
    // What? Of course that's not going to happen here! Do you think we're amateurs? [2])
    // ---
    // [2]: To provide some insight into the good doctor's commentary, the game loads cats from the save file by:
    //          A) saving the current RNG context
    //          B) constructing a CatData structure
    //          C) initializing the CatData with some field randomization (this advances RNG context)
    //          D) deserializing the saved cat into the CatData structure, overwriting any relevant fields
    //          E) initializing the body parts compartment of the CatData
    //          F) restoring RNG state
    //      Dr. Beanies recognized a shortcut and decided to omit steps C and E to save some work,
    //      since he didn't intend for this cat to be rendered in the world.
    //      By omitting those steps, he notices he isn't disturbing RNG, so he further omits steps A and F.

    // Aww, poor li'l guy! It's barely a cat at this stage!
    // Let's fix that!
    glaiel__SerializeCatData(new_cat.get(), &byte_stream, false);

    // (And that is the technique of cat resurrection!)

    // [...]
    // Hmm? Yes, we're done.
    // [...]
    // The cat? Take it with you!
    return new_cat;
}

void overwrite_cat(CatData *target_cat, int64_t source_sql_id) {
    MewDirector *p_md = get_p_mewdirector_singleton();

    if(p_md == nullptr) {
        return;
    }

    std::vector<char> decompressed_cat;
    G.sqlite3.exec_path(
        std::filesystem::path(p_md->sqlsavefile.file_path.as_native_string_view()),
        "SELECT data from cats WHERE key = :key;",
        {std::make_pair(":key", source_sql_id)},
        [&decompressed_cat](sqlite3_stmt * stmt) -> bool {
            const char *blob = reinterpret_cast<const char *>(sqlite3_column_blob(stmt, 0));
            int size = sqlite3_column_bytes(stmt, 0);

            if(size == 0) {
                D::warn("A cat blob in the cats table has 0 size!");
                return false;
            }

            int decompressed_size = reinterpret_cast<const int *>(blob)[0];
            decompressed_cat.resize(decompressed_size);
            if(LZ4_decompress_safe(blob + 4, decompressed_cat.data(), size - 4, decompressed_size) != decompressed_size) {
                D::error("An LZ4-compressed cat failed to decompress!");
                std::vector<char>().swap(decompressed_cat);
                return false;
            }

            return false;
        }
    );

    if(decompressed_cat.size() == 0) {
        return;
    }

    ByteStream byte_stream = {};
    byte_stream.direction_0_des_buffer_1_ser_buffer_2_ser_ostream = 0;
    byte_stream.either_platform_or_stream_endianness = 0;
    byte_stream.either_stream_or_platform_endianness = 0;
    byte_stream.maximum_auto_endian_swap_size = 8;
    byte_stream.string_intern_table = nullptr;
    byte_stream.des_buffer = decompressed_cat.data();
    byte_stream.des_buffer_size = static_cast<int>(decompressed_cat.size());
    byte_stream.des_buffer_needs_free = false;
    byte_stream.des_buffer_read_cursor = 0;


    glaiel__SerializeCatData(target_cat, &byte_stream, false);
}

std::unordered_map<int64_t, ManagedCatData> load_all_cats() {
    MewDirector *p_md = get_p_mewdirector_singleton();

    ByteStream byte_stream = {};
    byte_stream.direction_0_des_buffer_1_ser_buffer_2_ser_ostream = 0;
    byte_stream.either_platform_or_stream_endianness = 0;
    byte_stream.either_stream_or_platform_endianness = 0;
    byte_stream.maximum_auto_endian_swap_size = 8;
    byte_stream.string_intern_table = nullptr;
    byte_stream.des_buffer = nullptr;
    byte_stream.des_buffer_size = 0;
    byte_stream.des_buffer_needs_free = false;
    byte_stream.des_buffer_read_cursor = 0;

    std::vector<char> decompressed_cat;
    std::unordered_map<int64_t, ManagedCatData> tracked_cats;

    if(p_md == nullptr) {
        return tracked_cats;
    }

    G.sqlite3.exec_path(
        std::filesystem::path(p_md->sqlsavefile.file_path.as_native_string_view()),
        "SELECT key, data from cats;",
        {},
        [&byte_stream, &decompressed_cat, &tracked_cats](sqlite3_stmt * stmt) -> bool {
            int64_t sql_key = sqlite3_column_int64(stmt, 0);
            const char *blob = reinterpret_cast<const char *>(sqlite3_column_blob(stmt, 1));
            int size = sqlite3_column_bytes(stmt, 1);

            if(size == 0) {
                D::warn("A cat blob in the cats table has 0 size!");
                return true;
            }

            int decompressed_size = reinterpret_cast<const int *>(blob)[0];
            decompressed_cat.resize(decompressed_size);
            if(LZ4_decompress_safe(blob + 4, decompressed_cat.data(), size - 4, decompressed_size) != decompressed_size) {
                D::error("An LZ4-compressed cat failed to decompress!");
                return true;
            }

            ManagedCatData new_cat = new_default_cat();

            byte_stream.des_buffer = decompressed_cat.data();
            byte_stream.des_buffer_size = static_cast<int>(decompressed_cat.size());
            byte_stream.des_buffer_read_cursor = 0;

            glaiel__SerializeCatData(new_cat.get(), &byte_stream, false);

            tracked_cats.try_emplace(sql_key, std::move(new_cat));

            return true;
        }
    );

    return tracked_cats;
}

// Hook this function so that we can suppress name history updates when we manually call the breed function
static bool glaiel__CatData_unk_init_register_in_name_history_override = false;
static bool glaiel__CatData_unk_init_register_in_name_history_val = false;
MAKE_SHOOK(0, ADDRESS_glaiel__CatData_unk_init,
    void, __cdecl, glaiel__CatData_unk_init,
    CatData *p_cat, void *ofstream_eliminated_by_opt, int32_t sex, bool register_in_name_history
) {
    bool our_register_in_name_history =
        glaiel__CatData_unk_init_register_in_name_history_override ?
        glaiel__CatData_unk_init_register_in_name_history_val :
        register_in_name_history;
    glaiel__CatData_unk_init_hook.orig(p_cat, ofstream_eliminated_by_opt, sex, our_register_in_name_history);
}

MAKE_SFPORTAL(ADDRESS_glaiel__CatData_unk_init,
    CatData *, __cdecl, glaiel__CatData_unk_init,
    (CatData *p_cat, void *ofstream_eliminated_by_opt, int32_t sex, bool register_in_name_history),
    (p_cat, ofstream_eliminated_by_opt, sex, register_in_name_history)
)

MAKE_SFPORTAL(ADDRESS_glaiel__CatData_unk_init_bodyparts,
    void, __cdecl, glaiel__CatData_unk_init_bodyparts,
    (BodyParts *p_bodyparts),
    (p_bodyparts)
)

MAKE_SFPORTAL(ADDRESS_glaiel__CatData__breed,
    void, __cdecl, glaiel__CatData__breed,
    (CatData *p_kitten, CatData *p_parent_a, CatData *p_parent_b, double coi, void *vector_of_furniture_effects),
    // TODO furniture effects, the house interstitial function retrieves vector_of_furniture_effects based on the room where the deed was done
    (p_kitten, p_parent_a, p_parent_b, coi, vector_of_furniture_effects)
)

ManagedCatData make_stray(Xoshiro256pContext *rng_override) {
    Xoshiro256pContext &rng = get_xoshiro256p_rng_context();
    Xoshiro256pContext rng_backup = rng;
    if(rng_override != nullptr) {
        rng = *rng_override;
    }
    ManagedCatData cat = new_default_cat();
    // "Now I am become Cat, destroyer of worlds, small animals, and upholstery"
    glaiel__CatData_unk_init(cat.get(), nullptr, 3, false);
    glaiel__CatData_unk_init_bodyparts(&cat->body_parts);
    if(rng_override != nullptr) {
        *rng_override = rng;
    }
    rng = rng_backup;
    return cat;
}

struct ParentCOINativeHasher {
    size_t operator()(const ParentCOIK &self) const noexcept {
        // NOT the same as the game's internal hash implementation
        // return ParentCOIKHasher::hash(&self);

        // Slightly improved (FNV1a_64(a concat b)) over the game's implementation (FNV1a_64(a) ^ FNV1a_64(b)),
        // as the parent_a == parent_b case used by self-kinship calculations does not universally map to hash 0
        uint64_t digest = 0xcbf29ce484222325;
        for(int i = 0; i < 8; i++) {
            uint8_t byte = static_cast<uint8_t>(self.parent_a >> (8 * i));
            digest ^= byte;
            digest *= 0x100000001b3;
        }
        for(int i = 0; i < 8; i++) {
            uint8_t byte = static_cast<uint8_t>(self.parent_b >> (8 * i));
            digest ^= byte;
            digest *= 0x100000001b3;
        }
        return digest;
    }
};

double calculate_coi(int64_t parent_a_key, int64_t parent_b_key) {
    MewDirector *p_md = get_p_mewdirector_singleton();
    if(p_md == nullptr) {
        return 0.0;
    }

    // We use as much of the game's precomputed information as reasonable
    // (i.e. we'll look through its pedigree and memo map and opportunistically use any memoized numbers)
    // but we do reimplement the main body of the algorithm to avoid mutating the game's memo map
    auto &pedigree_map = p_md->cats->pedigree.child_to_parents_and_coi_map;
    auto &memo_map = p_md->cats->pedigree.parents_to_coi_memo_map;

    // This is our augmentation to the game's memo_map
    // We don't save it to avoid needing to invalidate entries between save reloads
    std::unordered_map<ParentCOIK, double, ParentCOINativeHasher> our_memo;

    std::stack<ParentCOIK> workstack;
    ParentCOIK query_pair = {std::min(parent_a_key, parent_b_key), std::max(parent_a_key, parent_b_key)};
    workstack.push(query_pair);

    while(!workstack.empty()) {
        auto pair = workstack.top();
        int64_t cat_x_id = pair.parent_a;
        int64_t cat_y_id = pair.parent_b;

        // Use our memoized value if found
        if(auto our_memo_it = our_memo.find(pair); our_memo_it != our_memo.end()) {
            workstack.pop();
            continue;
        }

        // Use game's memoized value if found
        if(auto memo_entry = memo_map.get(&pair); memo_entry != nullptr) {
            our_memo[pair] = memo_entry->val;
            workstack.pop();
            continue;
        }

        // Starter or stray cat
        if(cat_x_id == -1 || cat_y_id == -1) {
            our_memo[pair] = 0.0;
            workstack.pop();
            continue;
        }

        auto cat_x_pedigree = pedigree_map.get(&cat_x_id);
        auto cat_y_pedigree = pedigree_map.get(&cat_y_id);

        // Self-kinship (base)
        // ϕ(y, y) = 0.5(1 + COI(y))
        if(cat_x_id == cat_y_id) {
            if(cat_y_pedigree != nullptr) {
                our_memo[pair] = 0.5 * (1.0 + cat_y_pedigree->val.coi);
            } else {
                // Cat not found in the pedigree map.
                // Perform the calculation as if the cat's COI were 0.0 (self-kinship is 0.5).
                our_memo[pair] = 0.5 * (1.0 + 0.0);  // i.e. 0.5
            }
            workstack.pop();
            continue;
        }

        // Mutual-kinship (recursive)
        // ϕ(x, y) = 0.5(ϕ(x, y.parent_a) + ϕ(x, y.parent_b))

        // Either cat not found in the pedigree map
        // Perform the calculation as if both cats' COIs were 0.0.
        if(cat_x_pedigree == nullptr || cat_y_pedigree == nullptr) {
            our_memo[pair] = 0.5 * (0.0 + 0.0); // i.e. 0.0
            workstack.pop();
            continue;
        }

        ParentCOIK pair_x_cross_y_parent_a = {std::min(cat_x_id, cat_y_pedigree->val.parent_a), std::max(cat_x_id, cat_y_pedigree->val.parent_a)};
        ParentCOIK pair_x_cross_y_parent_b = {std::min(cat_x_id, cat_y_pedigree->val.parent_b), std::max(cat_x_id, cat_y_pedigree->val.parent_b)};
        auto pair_x_cross_y_parent_a_memo_it = our_memo.find(pair_x_cross_y_parent_a);
        auto pair_x_cross_y_parent_b_memo_it = our_memo.find(pair_x_cross_y_parent_b);
        if(pair_x_cross_y_parent_a_memo_it != our_memo.end() && pair_x_cross_y_parent_b_memo_it != our_memo.end()) {
            our_memo[pair] = 0.5 * (pair_x_cross_y_parent_a_memo_it->second + pair_x_cross_y_parent_b_memo_it->second);
            workstack.pop();
        } else {
            // The recursive step will check the game's memo or recalculate as much as necessary
            if(pair_x_cross_y_parent_a_memo_it == our_memo.end()) {
                workstack.push(pair_x_cross_y_parent_a);
            }
            if(pair_x_cross_y_parent_b_memo_it == our_memo.end()) {
                workstack.push(pair_x_cross_y_parent_b);
            }
            // Don't pop the current stack entry, we will need to circle back once the 2 deps are met
        }
    }

    return our_memo[query_pair];
}

ManagedCatData make_kitten(CatData *p_parent_a, CatData *p_parent_b, double coi, Xoshiro256pContext *rng_override) {
    Xoshiro256pContext &rng = get_xoshiro256p_rng_context();
    Xoshiro256pContext rng_backup = rng;
    if(rng_override != nullptr) {
        rng = *rng_override;
    }
    ManagedCatData kitten = new_default_cat();
    glaiel__CatData_unk_init_register_in_name_history_override = true;
    glaiel__CatData_unk_init_register_in_name_history_val = false;
    // Test tube kitty!
    glaiel__CatData__breed(kitten.get(), p_parent_a, p_parent_b, coi, nullptr);
    glaiel__CatData_unk_init_register_in_name_history_override = false;
    if(rng_override != nullptr) {
        *rng_override = rng;
    }
    rng = rng_backup;
    return kitten;
}
